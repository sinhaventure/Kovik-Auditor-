# -*- coding: utf-8 -*-
"""Kovik SEO Audit Engine.

    python audit.py https://example.com --pages 10 --out report.pdf
"""
import argparse
import csv
import json
import os
import sys
import time

from kovik_audit.crawler import Crawler
from kovik_audit.analyze import Analyzer, WEIGHTS
from kovik_audit.report import AuditReport

BOLD, DIM, TEAL, CLAY, RESET = "\033[1m", "\033[2m", "\033[36m", "\033[31m", "\033[0m"


def color(txt, code):
    return txt if os.environ.get("NO_COLOR") else f"{code}{txt}{RESET}"


def banner():
    print()
    print(color("  KOVIK  ", TEAL) + color("· SEO AUDIT ENGINE", BOLD))
    print(color("  powered by Kovik Intelligence AI · kovik.online", DIM))
    print()


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="audit.py",
        description="Crawl a website and produce a scored SEO audit report (PDF, JSON, CSV).")
    ap.add_argument("url", help="Start URL, e.g. https://example.com")
    ap.add_argument("--pages", type=int, default=10, help="Maximum pages to crawl (default 10)")
    ap.add_argument("--depth", type=int, default=2, help="Link depth from the start URL (default 2)")
    ap.add_argument("--out", default=None, help="Output PDF path (default audit-<host>.pdf)")
    ap.add_argument("--json", dest="json_out", default=None, help="Also write raw results as JSON")
    ap.add_argument("--csv", dest="csv_out", default=None, help="Also write the issue list as CSV")
    ap.add_argument("--brand", default="Kovik Digital Solutions", help="Brand name on the report")
    ap.add_argument("--client", default="", help="Client name shown on the cover")
    ap.add_argument("--delay", type=float, default=0.4, help="Seconds between requests (be polite)")
    ap.add_argument("--quiet", action="store_true", help="Suppress crawl progress")
    ap.add_argument("--label", default="", help="Public URL to show on the report "
                                               "(useful when auditing a staging copy)")
    args = ap.parse_args(argv)

    if not args.url.startswith(("http://", "https://")):
        args.url = "https://" + args.url

    banner()
    t0 = time.time()
    crawler = Crawler(args.url, max_pages=args.pages, max_depth=args.depth,
                      delay=args.delay, verbose=not args.quiet)
    print(color("Crawling", BOLD))
    crawler.run()
    if not crawler.pages:
        print(color("Could not fetch the site. Check the URL and the connection.", CLAY))
        return 2

    print(color(f"\nAnalysing {len(crawler.pages)} pages", BOLD))
    analyzer = Analyzer(crawler)
    analyzer.run()
    scores = analyzer.scores()
    issues = analyzer.issues()

    # terminal summary
    print()
    print(f"  Overall score  {color(f'{scores['Overall']:.0f}/100', BOLD)}  ({analyzer.grade(scores['Overall'])})")
    for cat in WEIGHTS:
        bar = "█" * int(scores[cat] / 5) + "░" * (20 - int(scores[cat] / 5))
        print(f"  {cat:<16} {color(bar, TEAL)} {scores[cat]:.0f}")
    print()
    fails = [c for c in issues if c.status == "fail"]
    warns = [c for c in issues if c.status == "warn"]
    print(f"  {color(str(len(fails)), CLAY)} failing · {len(warns)} to improve")
    for c in issues[:6]:
        tag = color("FIX ", CLAY) if c.status == "fail" else color("IMPR", DIM)
        print(f"    {tag} [{c.severity:<8}] {c.title}")
    print()

    host = args.url.split("://", 1)[1].split("/")[0].replace("www.", "")
    label = args.label.strip()
    if label:
        host = label.split("://", 1)[-1].split("/")[0].replace("www.", "")
    out = args.out or f"audit-{host}-{time.strftime('%Y%m%d')}.pdf"

    report = AuditReport(analyzer, args.url, brand=args.brand, client=args.client,
                         site_name=host, display_site=label or "")
    report.build(out)
    print(f"  PDF  → {color(out, BOLD)}")

    if args.json_out:
        payload = {
            "url": args.url,
            "generated": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "pages_crawled": len(crawler.pages),
            "scores": scores,
            "checks": [c.__dict__ for c in analyzer.checks],
            "pages": analyzer.page_rows(),
        }
        with open(args.json_out, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2)
        print(f"  JSON → {args.json_out}")

    if args.csv_out:
        with open(args.csv_out, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["severity", "category", "check", "status", "detail", "fix", "affected"])
            for c in issues:
                w.writerow([c.severity, c.category, c.title, c.status, c.detail, c.fix,
                            " | ".join(report.disp(u) for u in c.affected[:10])])
        print(f"  CSV  → {args.csv_out}")

    print(color(f"\n  Done in {time.time() - t0:.1f}s\n", DIM))
    return 0


if __name__ == "__main__":
    sys.exit(main())
