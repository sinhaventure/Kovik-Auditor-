# Kovik SEO Audit Engine

A real crawler. It fetches your pages, parses the HTML, runs 26 checks, scores five
categories, and writes a branded PDF report — with the Kovik watermark and
"Powered by Kovik Intelligence AI" on every page.

No API keys. No third-party SEO service. It runs on your machine or a ₹300 VPS.

---

## Install

```bash
pip install -r requirements.txt
```

Python 3.9+.

## Run

```bash
python audit.py https://client-site.in --pages 10 --out client-audit.pdf
```

That crawls up to 10 pages, prints a score summary in the terminal, and writes
`client-audit.pdf`.

### Useful options

| Flag | What it does |
|---|---|
| `--pages 12` | Crawl up to 12 pages (8–12 is the sweet spot for a small business site) |
| `--depth 2` | How many link-hops from the home page |
| `--out report.pdf` | Where to write the PDF |
| `--json data.json` | Also dump every measurement as JSON (for a dashboard) |
| `--csv issues.csv` | Also dump the issue list as CSV (for a spreadsheet) |
| `--client "Sharma Dental"` | Prints the client name on the cover |
| `--label https://client-site.in` | Public URL to show when you audit a staging copy |
| `--delay 0.5` | Seconds between requests — keep it polite on small servers |

### Example

```bash
python audit.py https://sharmadental.in \
  --pages 12 --depth 2 \
  --client "Sharma Dental Clinic, Hajipur" \
  --out sharma-dental-audit.pdf --csv sharma-dental-issues.csv
```

---

## What it checks (26 checks, five categories)

**Technical (30% of the score)**
HTTPS, robots.txt reachable, XML sitemap present, real 404 handling, broken pages,
redirect chains, canonical tags, accidental noindex, mobile viewport, page language.

**On-page (25%)**
Title tags present and sized, duplicate titles, meta descriptions, duplicate
descriptions, single H1, H2 structure, image alt coverage.

**Content (20%)**
Word count per page (thin content), internal links per page.

**Structured data (15%)**
JSON-LD present and valid, which schema types were found, Open Graph tags,
LocalBusiness / Organization identity markup.

**Performance (10%)**
Server response time, HTML weight, gzip/brotli compression, cache headers.

Scoring: each check is weighted inside its category; a pass scores 1, an
improvement 0.5, a failure 0. Categories are then weighted into the overall score.

---

## The report

* **Cover** — brand, site, date, overall score ring, what's inside.
* **Executive summary** — score card, category bar chart, the five things to fix first.
* **Findings in detail** — grouped by severity (critical → low). Each finding shows what
  was measured, which pages were affected, and what to do about it.
* **Page-by-page table** — status, per-page score, title/description length, H1 count,
  words, missing alt text, response time, page weight.
* **Method and limits** — what the audit does *not* cover, so nobody over-claims.

Every page carries a diagonal **KOVIK DIGITAL SOLUTIONS** watermark and a footer with
**Powered by Kovik Intelligence AI · kovik.online**.

---

## Honest limits

* One crawl, from one location, at one moment. Response times are a signal, not a
  benchmark — run it twice before quoting numbers.
* No backlink data, no search volume, no rank tracking, no Core Web Vitals field data.
  Those need Search Console, Analytics and a rank tracker.
* JavaScript-rendered content is not executed. If a site builds its content client-side,
  the crawler sees an empty page — that is itself a finding worth reporting.

## Extending it

* `kovik_audit/crawler.py` — fetching and parsing. Add fields to `Page`, fill them in
  `parse()`.
* `kovik_audit/analyze.py` — one method per check. Copy an existing `check_*` method,
  call it from `run()`, give it a weight.
* `kovik_audit/report.py` — layout. Colours and brand strings live at the top.

---

Kovik Digital Solutions · Hajipur, Bihar · kovik.online · +91 91992 64615
