"""Kovik SEO Audit Engine — in-house crawler, scorer and PDF reporter."""
__version__ = "1.0.0"
