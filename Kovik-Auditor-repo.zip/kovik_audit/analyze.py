# -*- coding: utf-8 -*-
"""Kovik SEO Audit Engine — checks and scoring."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from urllib.parse import urlparse

import requests

from .crawler import Page, UA, norm

WEIGHTS = {
    "Technical": 0.30,
    "On-page": 0.25,
    "Content": 0.20,
    "Structured data": 0.15,
    "Performance": 0.10,
}

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
STATUS_VALUE = {"pass": 1.0, "warn": 0.5, "fail": 0.0, "info": 1.0}


@dataclass
class Check:
    id: str
    category: str
    title: str
    severity: str
    status: str
    detail: str
    fix: str
    affected: List[str] = field(default_factory=list)
    weight: float = 1.0


def short(url: str, n: int = 48) -> str:
    p = urlparse(url)
    path = p.path or "/"
    s = p.netloc + path
    return s if len(s) <= n else s[: n - 1] + "…"


class Analyzer:
    def __init__(self, crawler, timeout: int = 15):
        self.c = crawler
        self.pages: List[Page] = [p for p in crawler.pages]
        self.ok_pages: List[Page] = [p for p in self.pages if p.status < 400 and not p.error]
        self.base = crawler.start
        self.timeout = timeout
        self.checks: List[Check] = []
        self._404_status: Optional[int] = None

    # ------------------------------------------------------------------ util
    def add(self, id, category, title, severity, status, detail, fix, affected=None, weight=1.0):
        self.checks.append(Check(id, category, title, severity, status, detail, fix,
                                 affected or [], weight))

    def _fetch_status(self, url: str) -> int:
        try:
            r = requests.get(url, headers={"User-Agent": UA}, timeout=self.timeout, allow_redirects=True)
            return r.status_code
        except requests.RequestException:
            return 0

    # ---------------------------------------------------------------- checks
    def run(self) -> List[Check]:
        self.check_https()
        self.check_robots()
        self.check_sitemap()
        self.check_404()
        self.check_status_codes()
        self.check_redirects()
        self.check_canonical()
        self.check_noindex()
        self.check_viewport()
        self.check_lang()
        self.check_titles()
        self.check_title_dupes()
        self.check_descriptions()
        self.check_desc_dupes()
        self.check_h1()
        self.check_headings()
        self.check_alt()
        self.check_internal_links()
        self.check_thin_content()
        self.check_jsonld()
        self.check_og()
        self.check_local_schema()
        self.check_speed()
        self.check_weight()
        self.check_compression()
        self.check_cache()
        return self.checks

    def check_https(self):
        bad = [p.url for p in self.ok_pages if not p.https]
        self.add("https", "Technical", "HTTPS on every page", "critical",
                 "fail" if bad else "pass",
                 f"{len(bad)} of {len(self.ok_pages)} pages are served over plain HTTP." if bad
                 else "Every crawled page is served over HTTPS.",
                 "Serve the whole site over HTTPS and 301-redirect http:// to https://.",
                 bad, 1.4)

    def check_robots(self):
        exists = bool(self.c.robots_url) and self._fetch_status(self.c.robots_url) == 200
        self.add("robots", "Technical", "robots.txt reachable", "high",
                 "pass" if exists else "fail",
                 f"{self.c.robots_url} returns 200." if exists
                 else "No robots.txt found — search engines get no crawl guidance.",
                 "Publish a robots.txt that allows crawling and points to your sitemap.",
                 [] if exists else [self.c.robots_url], 1.0)

    def check_sitemap(self):
        parsed = urlparse(self.base)
        candidates = self.c.sitemap_urls or [f"{parsed.scheme}://{parsed.netloc}/sitemap.xml"]
        found, count = "", 0
        for url in candidates:
            try:
                r = requests.get(url, headers={"User-Agent": UA}, timeout=self.timeout)
                if r.status_code == 200 and "<url" in r.text.lower():
                    found = url
                    count = r.text.lower().count("<url>")
                    break
            except requests.RequestException:
                continue
        self.add("sitemap", "Technical", "XML sitemap present", "high",
                 "pass" if found else "fail",
                 f"{found} lists {count} URLs." if found else "No usable sitemap.xml was found.",
                 "Publish an XML sitemap, list every indexable page, and submit it in Search Console.",
                 [] if found else [candidates[0]], 1.2)

    def check_404(self):
        parsed = urlparse(self.base)
        probe = f"{parsed.scheme}://{parsed.netloc}/kovik-audit-missing-page-{abs(hash(self.base)) % 9999}"
        code = self._fetch_status(probe)
        self._404_status = code
        ok = code == 404
        self.add("404", "Technical", "Broken URLs return 404", "medium",
                 "pass" if ok else ("warn" if code in (403, 410) else "fail"),
                 f"A non-existent URL returned HTTP {code}." + (" Correct." if ok else
                 " Search engines treat a 200 here as a soft 404 and waste crawl budget."),
                 "Serve a real 404 status for missing pages, with a helpful page body.",
                 [], 0.8)

    def check_status_codes(self):
        bad = [p for p in self.pages if p.status >= 400]
        self.add("status", "Technical", "No broken pages in the crawl", "critical",
                 "pass" if not bad else "fail",
                 "All crawled pages returned a healthy status." if not bad
                 else f"{len(bad)} crawled pages returned an error status.",
                 "Fix or redirect every URL that returns 4xx or 5xx.",
                 [f"{short(p.url)} → HTTP {p.status}" for p in bad], 1.5)

    def check_redirects(self):
        red = [p for p in self.ok_pages if p.redirect_chain]
        self.add("redirects", "Technical", "Pages resolve without redirect chains", "low",
                 "pass" if not red else "warn",
                 "No redirect chains found." if not red
                 else f"{len(red)} pages reached their final URL through a redirect.",
                 "Link to the final URL directly; keep redirects to a single hop.",
                 [short(p.url) for p in red], 0.6)

    def check_canonical(self):
        missing = [p for p in self.ok_pages if not p.canonical]
        self.add("canonical", "Technical", "Canonical tag on every page", "high",
                 "pass" if not missing else "fail",
                 "Every page declares a canonical URL." if not missing
                 else f"{len(missing)} pages have no canonical tag.",
                 "Add a self-referencing canonical link to every indexable page.",
                 [short(p.url) for p in missing], 1.0)

    def check_noindex(self):
        blocked = [p for p in self.ok_pages if "noindex" in (p.robots_meta or "").lower()]
        self.add("noindex", "Technical", "No accidental noindex", "critical",
                 "pass" if not blocked else "warn",
                 "No crawled page is marked noindex." if not blocked
                 else f"{len(blocked)} pages are marked noindex and will not rank.",
                 "Remove the noindex meta from any page you want in search results.",
                 [short(p.url) for p in blocked], 1.2)

    def check_viewport(self):
        bad = [p for p in self.ok_pages if not p.viewport]
        self.add("viewport", "Technical", "Mobile viewport declared", "high",
                 "pass" if not bad else "fail",
                 "Every page declares a responsive viewport." if not bad
                 else f"{len(bad)} pages have no viewport meta tag.",
                 'Add <meta name="viewport" content="width=device-width, initial-scale=1">.',
                 [short(p.url) for p in bad], 1.0)

    def check_lang(self):
        bad = [p for p in self.ok_pages if not p.lang]
        self.add("lang", "Technical", "Page language declared", "low",
                 "pass" if not bad else "warn",
                 "Every page declares a language." if not bad
                 else f"{len(bad)} pages have no lang attribute.",
                 'Add lang="en-IN" (or the correct language) to the <html> element.',
                 [short(p.url) for p in bad], 0.5)

    # --------------------------------------------------------------- on-page
    def check_titles(self):
        missing = [p for p in self.ok_pages if not p.title]
        short_t = [p for p in self.ok_pages if 0 < len(p.title) < 25]
        long_t = [p for p in self.ok_pages if len(p.title) > 62]
        status = "fail" if missing else ("warn" if (short_t or long_t) else "pass")
        detail = "Every page has a title of a sensible length." if status == "pass" else \
            f"{len(missing)} pages without a title, {len(short_t)} too short, {len(long_t)} too long."
        self.add("title", "On-page", "Title tags present and well sized", "critical", status, detail,
                 "Write a unique 30–60 character title per page: service + city + brand.",
                 [short(p.url) for p in (missing + short_t + long_t)], 1.6)

    def check_title_dupes(self):
        seen: Dict[str, List[str]] = {}
        for p in self.ok_pages:
            if p.title:
                seen.setdefault(p.title.strip().lower(), []).append(short(p.url))
        dupes = {k: v for k, v in seen.items() if len(v) > 1}
        self.add("title_dupes", "On-page", "No duplicate title tags", "high",
                 "pass" if not dupes else "fail",
                 "All titles are unique." if not dupes
                 else f"{len(dupes)} titles are shared by more than one page.",
                 "Give every page its own title; duplicates compete with each other.",
                 [u for v in dupes.values() for u in v], 1.2)

    def check_descriptions(self):
        missing = [p for p in self.ok_pages if not p.meta_description]
        short_d = [p for p in self.ok_pages if 0 < len(p.meta_description) < 70]
        long_d = [p for p in self.ok_pages if len(p.meta_description) > 165]
        status = "fail" if missing else ("warn" if (short_d or long_d) else "pass")
        self.add("description", "On-page", "Meta descriptions written", "high", status,
                 "Every page has a well-sized meta description." if status == "pass" else
                 f"{len(missing)} pages without one, {len(short_d)} too short, {len(long_d)} too long.",
                 "Write a 120–160 character description that gives a reason to click.",
                 [short(p.url) for p in (missing + short_d + long_d)], 1.3)

    def check_desc_dupes(self):
        seen: Dict[str, List[str]] = {}
        for p in self.ok_pages:
            if p.meta_description:
                seen.setdefault(p.meta_description.strip().lower(), []).append(short(p.url))
        dupes = {k: v for k, v in seen.items() if len(v) > 1}
        self.add("desc_dupes", "On-page", "No duplicate meta descriptions", "medium",
                 "pass" if not dupes else "warn",
                 "All descriptions are unique." if not dupes
                 else f"{len(dupes)} descriptions are repeated across pages.",
                 "Write a distinct description for each page.",
                 [u for v in dupes.values() for u in v], 0.8)

    def check_h1(self):
        none = [p for p in self.ok_pages if not p.h1]
        many = [p for p in self.ok_pages if len(p.h1) > 1]
        status = "fail" if none else ("warn" if many else "pass")
        self.add("h1", "On-page", "One clear H1 per page", "high", status,
                 "Every page has exactly one H1." if status == "pass" else
                 f"{len(none)} pages have no H1, {len(many)} have more than one.",
                 "Use a single H1 that states the page's subject, then H2 for sections.",
                 [short(p.url) for p in (none + many)], 1.3)

    def check_headings(self):
        no_h2 = [p for p in self.ok_pages if not p.h2]
        self.add("headings", "On-page", "Sections marked with H2", "low",
                 "pass" if not no_h2 else "warn",
                 "Every page has section headings." if not no_h2
                 else f"{len(no_h2)} pages jump straight from H1 to body text.",
                 "Break content into H2 sections so both readers and crawlers can scan it.",
                 [short(p.url) for p in no_h2], 0.6)

    def check_alt(self):
        total = sum(p.images for p in self.ok_pages)
        missing = sum(p.images_no_alt for p in self.ok_pages)
        ratio = (missing / total) if total else 0
        status = "pass" if missing == 0 else ("warn" if ratio < 0.3 else "fail")
        affected = [f"{short(p.url)} — {p.images_no_alt} of {p.images} images"
                    for p in self.ok_pages if p.images_no_alt]
        self.add("alt", "On-page", "Images have alt text", "medium", status,
                 f"{missing} of {total} images have no alt text." if total else "No images found.",
                 "Describe what each image shows; alt text feeds image search and accessibility.",
                 affected, 1.0)

    def check_internal_links(self):
        thin = [p for p in self.ok_pages if p.internal_links < 5]
        self.add("internal_links", "Content", "Pages link to each other", "medium",
                 "pass" if not thin else "warn",
                 "Every page carries at least five internal links." if not thin
                 else f"{len(thin)} pages have fewer than five internal links.",
                 "Link related pages from the body copy, not just the menu.",
                 [short(p.url) for p in thin], 0.9)

    def check_thin_content(self):
        thin = [p for p in self.ok_pages if p.words < 300]
        status = "pass" if not thin else ("warn" if len(thin) <= 2 else "fail")
        self.add("thin", "Content", "Enough substance on the page", "high", status,
                 "Every page carries at least 300 words." if not thin
                 else f"{len(thin)} pages carry under 300 words of visible text.",
                 "Add the detail a customer needs: what is included, prices, timings, proof.",
                 [f"{short(p.url)} — {p.words} words" for p in thin], 1.2)

    # ------------------------------------------------------- structured data
    def check_jsonld(self):
        missing = [p for p in self.ok_pages if not p.jsonld_blocks]
        invalid = [p for p in self.ok_pages if p.jsonld_blocks and p.jsonld_valid < len(p.jsonld_blocks)]
        status = "pass" if not missing and not invalid else ("warn" if not missing else "fail")
        types = sorted({t for p in self.ok_pages for t in p.jsonld_types})
        self.add("jsonld", "Structured data", "Schema.org markup", "high", status,
                 (f"Valid JSON-LD on every page. Types found: {', '.join(types[:8])}." if status == "pass"
                  else f"{len(missing)} pages have no JSON-LD; {len(invalid)} have invalid blocks."),
                 "Add LocalBusiness/Organization plus page-type schema, and validate it.",
                 [short(p.url) for p in (missing + invalid)], 1.3)

    def check_og(self):
        need = ["og:title", "og:description", "og:image"]
        bad = [p for p in self.ok_pages if any(k not in p.og_tags for k in need)]
        self.add("og", "Structured data", "Open Graph tags for sharing", "low",
                 "pass" if not bad else "warn",
                 "Every page is ready to share." if not bad
                 else f"{len(bad)} pages are missing some Open Graph tags.",
                 "Add og:title, og:description and a 1200×630 og:image to every page.",
                 [short(p.url) for p in bad], 0.7)

    def check_local_schema(self):
        local_types = {"LocalBusiness", "ProfessionalService", "Store", "MedicalBusiness",
                       "Restaurant", "Dentist", "Organization"}
        found = any(local_types & set(p.jsonld_types) for p in self.ok_pages)
        self.add("local_schema", "Structured data", "Local business identity markup", "medium",
                 "pass" if found else "warn",
                 "A business entity type is declared." if found
                 else "No LocalBusiness or Organization entity was found in the markup.",
                 "Declare your business once — name, address, phone, hours, area served.",
                 [], 0.9)

    # ---------------------------------------------------------- performance
    def check_speed(self):
        times = [p.elapsed_ms for p in self.ok_pages if p.elapsed_ms]
        avg = int(sum(times) / len(times)) if times else 0
        slow = [p for p in self.ok_pages if p.elapsed_ms > 1200]
        status = "pass" if avg and avg < 800 and not slow else ("warn" if avg < 1500 else "fail")
        self.add("speed", "Performance", "Server responds quickly", "high", status,
                 f"Average response time {avg} ms across {len(times)} pages.",
                 "Move to a host close to your customers and enable server-side caching.",
                 [f"{short(p.url)} — {p.elapsed_ms} ms" for p in slow], 1.3)

    def check_weight(self):
        heavy = [p for p in self.ok_pages if p.bytes > 500_000]
        avg_kb = int(sum(p.bytes for p in self.ok_pages) / max(len(self.ok_pages), 1) / 1024)
        status = "pass" if not heavy else "warn"
        self.add("weight", "Performance", "Page weight under control", "medium", status,
                 f"Average HTML weight {avg_kb} KB; {len(heavy)} pages above 500 KB.",
                 "Compress images, drop unused scripts and defer what is not needed first.",
                 [f"{short(p.url)} — {p.bytes // 1024} KB" for p in heavy], 1.0)

    def check_compression(self):
        enc = [p.headers.get("content-encoding", "") for p in self.ok_pages]
        good = sum(1 for e in enc if any(k in e for k in ("gzip", "br", "zstd")))
        status = "pass" if self.ok_pages and good == len(self.ok_pages) else ("warn" if good else "fail")
        self.add("compression", "Performance", "Text compression enabled", "medium", status,
                 f"{good} of {len(self.ok_pages)} pages were served compressed.",
                 "Enable gzip or brotli on the server — it usually halves transfer size.",
                 [], 0.9)

    def check_cache(self):
        cached = [p for p in self.ok_pages if p.headers.get("cache-control")]
        status = "pass" if self.ok_pages and len(cached) == len(self.ok_pages) else "warn"
        self.add("cache", "Performance", "Cache headers set", "low", status,
                 f"{len(cached)} of {len(self.ok_pages)} pages send a Cache-Control header.",
                 "Set long cache lifetimes on assets and a short one on HTML.",
                 [], 0.6)

    # -------------------------------------------------------------- scoring
    def scores(self) -> Dict[str, float]:
        out = {}
        for cat, weight in WEIGHTS.items():
            items = [c for c in self.checks if c.category == cat]
            if not items:
                out[cat] = 0.0
                continue
            num = sum(STATUS_VALUE[c.status] * c.weight for c in items)
            den = sum(c.weight for c in items)
            out[cat] = round(100 * num / den, 1)
        overall = sum(out[c] * w for c, w in WEIGHTS.items())
        out["Overall"] = round(overall, 1)
        return out

    def grade(self, score: float) -> str:
        if score >= 85:
            return "Strong"
        if score >= 70:
            return "Good, with gaps"
        if score >= 50:
            return "Needs work"
        return "Critical"

    def issues(self, only_failing: bool = True) -> List[Check]:
        items = [c for c in self.checks if c.status in ("fail", "warn")] if only_failing else list(self.checks)
        return sorted(items, key=lambda c: (SEVERITY_ORDER.get(c.severity, 9), c.status != "fail"))

    def page_rows(self) -> List[dict]:
        rows = []
        for p in self.ok_pages:
            problems = 0
            if not p.title:
                problems += 1
            if len(p.title) > 62:
                problems += 1
            if not p.meta_description:
                problems += 1
            if len(p.h1) != 1:
                problems += 1
            if p.images_no_alt:
                problems += 1
            if p.words < 300:
                problems += 1
            if not p.jsonld_blocks:
                problems += 1
            score = max(0, 100 - problems * 14)
            rows.append({
                "url": p.url,
                "status": p.status,
                "score": score,
                "title_len": len(p.title),
                "desc_len": len(p.meta_description),
                "h1": len(p.h1),
                "words": p.words,
                "imgs": p.images,
                "no_alt": p.images_no_alt,
                "ms": p.elapsed_ms,
                "kb": round(p.bytes / 1024),
                "jsonld": len(p.jsonld_blocks),
            })
        return rows
