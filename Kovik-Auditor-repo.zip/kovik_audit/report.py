# -*- coding: utf-8 -*-
"""Kovik SEO Audit Engine — PDF report."""
from __future__ import annotations

import os
import tempfile
from datetime import datetime
from typing import Dict, List

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Wedge

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.platypus import (BaseDocTemplate, Frame, Image, KeepTogether, PageBreak,
                                PageTemplate, Paragraph, Spacer, Table, TableStyle)

INK = colors.HexColor("#0b1210")
INK_SOFT = colors.HexColor("#16221e")
TEAL = colors.HexColor("#0e5e52")
MINT = colors.HexColor("#2fbfa4")
CLAY = colors.HexColor("#b4552f")
AMBER = colors.HexColor("#c08a2e")
GREY = colors.HexColor("#5c6a64")
LIGHT = colors.HexColor("#f2f5f3")
LINE = colors.HexColor("#dfe5e2")

SEV_COLOR = {
    "critical": colors.HexColor("#a3341f"),
    "high": colors.HexColor("#c0561f"),
    "medium": colors.HexColor("#b0821f"),
    "low": colors.HexColor("#4b6b62"),
    "info": GREY,
}
STATUS_LABEL = {"pass": "PASS", "warn": "IMPROVE", "fail": "FIX", "info": "INFO"}


class AuditReport:
    def __init__(self, analyzer, site_url: str, brand="Kovik Digital Solutions",
                 powered_by="Kovik Intelligence AI", site_name="kovik.online",
                 client: str = "", display_site: str = ""):
        self.a = analyzer
        self.site = display_site or site_url
        self._origin = analyzer.base
        self._disp_origin = (display_site or site_url).rstrip("/")
        self.brand = brand
        self.powered = powered_by
        self.site_name = site_name
        self.client = client
        self.scores = analyzer.scores()
        self.issues = analyzer.issues()
        self.date = datetime.now().strftime("%d %B %Y")
        self.tmp: List[str] = []
        self.styles = self._styles()

    def disp(self, url: str) -> str:
        """Show the public URL in the report even when the crawl ran on a mirror."""
        if self._disp_origin and self._origin and self._origin != self._disp_origin:
            return url.replace(self._origin.rstrip("/"), self._disp_origin)
        return url

    # ---------------------------------------------------------------- styles
    def _styles(self):
        ss = getSampleStyleSheet()
        add = ss.add
        add(ParagraphStyle("KBody", parent=ss["BodyText"], fontName="Helvetica",
                           fontSize=9.5, leading=14, textColor=colors.HexColor("#243330"),
                           alignment=TA_LEFT))
        add(ParagraphStyle("KSmall", parent=ss["BodyText"], fontName="Helvetica",
                           fontSize=8, leading=11.5, textColor=GREY))
        add(ParagraphStyle("KH1", parent=ss["Heading1"], fontName="Helvetica-Bold",
                           fontSize=17, leading=21, textColor=INK, spaceAfter=10, spaceBefore=4))
        add(ParagraphStyle("KH2", parent=ss["Heading2"], fontName="Helvetica-Bold",
                           fontSize=11.5, leading=15, textColor=TEAL, spaceBefore=14, spaceAfter=6))
        add(ParagraphStyle("KCell", parent=ss["BodyText"], fontName="Helvetica",
                           fontSize=7.6, leading=10, textColor=colors.HexColor("#243330")))
        add(ParagraphStyle("KCellB", parent=ss["BodyText"], fontName="Helvetica-Bold",
                           fontSize=7.6, leading=10, textColor=INK))
        add(ParagraphStyle("KEyebrow", parent=ss["BodyText"], fontName="Helvetica-Bold",
                           fontSize=7.5, leading=10, textColor=MINT))
        return ss

    # --------------------------------------------------------------- charts
    def _chart_scores(self) -> str:
        cats = [c for c in self.scores if c != "Overall"]
        vals = [self.scores[c] for c in cats]
        fig, ax = plt.subplots(figsize=(6.4, 2.5), dpi=200)
        fig.patch.set_facecolor("white")
        bars = ax.barh(cats, vals, color="#2fbfa4", height=0.55)
        for b, v in zip(bars, vals):
            b.set_color("#0e5e52" if v >= 70 else ("#b0821f" if v >= 50 else "#a3341f"))
            if v >= 88:
                ax.text(v - 4, b.get_y() + b.get_height() / 2, f"{v:.0f}", ha="right",
                        va="center", fontsize=8, color="white", fontweight="bold")
            else:
                ax.text(v + 2, b.get_y() + b.get_height() / 2, f"{v:.0f}",
                        va="center", fontsize=8, color="#243330", fontweight="bold")
        ax.set_xlim(0, 100)
        ax.set_xticks([0, 25, 50, 75, 100])
        ax.tick_params(colors="#5c6a64", labelsize=8)
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
        ax.spines["bottom"].set_color("#dfe5e2")
        ax.grid(axis="x", color="#eef2f0", linewidth=0.8)
        ax.set_axisbelow(True)
        path = os.path.join(tempfile.gettempdir(), "kovik_scores.png")
        fig.tight_layout()
        fig.savefig(path, facecolor="white")
        plt.close(fig)
        self.tmp.append(path)
        return path

    def _chart_severity(self) -> str:
        counts: Dict[str, int] = {}
        for c in self.issues:
            counts[c.severity] = counts.get(c.severity, 0) + 1
        order = [k for k in ("critical", "high", "medium", "low") if counts.get(k)]
        if not order:
            order, counts = ["low"], {"low": 1}
        sizes = [counts[k] for k in order]
        cols = {"critical": "#a3341f", "high": "#c0561f", "medium": "#b0821f", "low": "#4b6b62"}
        fig, ax = plt.subplots(figsize=(2.6, 2.6), dpi=200)
        ax.pie(sizes, colors=[cols[k] for k in order], startangle=90,
               wedgeprops=dict(width=0.38, edgecolor="white", linewidth=2))
        ax.text(0, 0.08, str(sum(sizes)), ha="center", va="center",
                fontsize=20, fontweight="bold", color="#0b1210")
        ax.text(0, -0.22, "issues", ha="center", va="center", fontsize=8, color="#5c6a64")
        path = os.path.join(tempfile.gettempdir(), "kovik_sev.png")
        fig.savefig(path, transparent=True, bbox_inches="tight")
        plt.close(fig)
        self.tmp.append(path)
        return path

    # ------------------------------------------------------------- decorate
    def _decorate(self, canv, doc):
        canv.saveState()
        w, h = A4
        if doc.page == 1:
            canv.setFillColor(INK)
            canv.rect(0, 0, w, h, stroke=0, fill=1)
            canv.setFillColor(colors.HexColor("#12211d"))
            canv.circle(w - 18 * mm, h - 26 * mm, 62 * mm, stroke=0, fill=1)
            canv.setFillColor(colors.HexColor("#0f1b18"))
            canv.circle(6 * mm, 34 * mm, 44 * mm, stroke=0, fill=1)
            self._cover_text(canv, w, h)
            canv.restoreState()
            return

        canv.setFillColor(colors.HexColor("#f7f9f8"))
        canv.rect(0, 0, w, h, stroke=0, fill=1)

        # diagonal watermark
        canv.saveState()
        canv.setFillColor(colors.Color(0.06, 0.16, 0.14, alpha=0.05))
        canv.setFont("Helvetica-Bold", 34)
        canv.translate(w / 2, h / 2)
        canv.rotate(38)
        canv.drawCentredString(0, 0, "KOVIK DIGITAL SOLUTIONS")
        canv.setFont("Helvetica-Bold", 13)
        canv.drawCentredString(0, -18 * mm, "POWERED BY KOVIK INTELLIGENCE AI")
        canv.restoreState()

        canv.setStrokeColor(LINE)
        canv.setLineWidth(0.6)
        canv.line(18 * mm, h - 16 * mm, w - 18 * mm, h - 16 * mm)
        canv.setFont("Helvetica-Bold", 7.5)
        canv.setFillColor(GREY)
        canv.drawString(18 * mm, h - 13.4 * mm, self.brand.upper())
        canv.drawRightString(w - 18 * mm, h - 13.4 * mm, self.site_name.upper())
        canv.line(18 * mm, 14 * mm, w - 18 * mm, 14 * mm)
        canv.setFont("Helvetica", 7)
        canv.setFillColor(GREY)
        canv.drawString(18 * mm, 10 * mm, f"Powered by {self.powered}  \u00b7  {self.site_name}")
        canv.drawRightString(w - 18 * mm, 10 * mm, f"Page {doc.page - 1}")
        canv.restoreState()

    def _cover_text(self, c, w, h):
        # brand mark
        c.setFillColor(TEAL)
        c.roundRect(20 * mm, h - 34 * mm, 13 * mm, 13 * mm, 3 * mm, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 15)
        c.drawCentredString(26.5 * mm, h - 30 * mm, "K")
        c.setFont("Helvetica-Bold", 11)
        c.drawString(37 * mm, h - 27 * mm, "KOVIK")
        c.setFont("Helvetica", 6.5)
        c.setFillColor(MINT)
        c.drawString(37 * mm, h - 30.6 * mm, "D I G I T A L   S O L U T I O N S")

        c.setFillColor(MINT)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(20 * mm, h - 58 * mm, "S E O   A U D I T   R E P O R T")

        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 26)
        c.drawString(20 * mm, h - 74 * mm, "Website visibility audit")

        c.setFillColor(colors.HexColor("#c9d8d2"))
        c.setFont("Helvetica", 11)
        c.drawString(20 * mm, h - 86 * mm, self.site[:70])

        y = h - 100 * mm
        if self.client:
            c.setFillColor(MINT)
            c.setFont("Helvetica-Bold", 7)
            c.drawString(20 * mm, y, "PREPARED FOR")
            c.setFillColor(colors.white)
            c.setFont("Helvetica", 12)
            c.drawString(20 * mm, y - 6 * mm, self.client)
            y -= 16 * mm

        # score block
        cx, cy, r = w - 62 * mm, h - 96 * mm, 26 * mm
        c.setStrokeColor(colors.HexColor("#1e332e"))
        c.setLineWidth(7)
        c.circle(cx, cy, r, stroke=1, fill=0)
        c.setStrokeColor(MINT)
        frac = max(0.0, min(1.0, self.scores["Overall"] / 100.0))
        c.setLineWidth(7)
        c.arc(cx - r, cy - r, cx + r, cy + r, startAng=90, extent=-360 * frac)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 30)
        c.drawCentredString(cx, cy + 2 * mm, f"{self.scores['Overall']:.0f}")
        c.setFillColor(colors.HexColor("#9fb4ad"))
        c.setFont("Helvetica", 7)
        c.drawCentredString(cx, cy - 8 * mm, "OUT OF 100")
        c.setFillColor(MINT)
        c.setFont("Helvetica-Bold", 9)
        c.drawCentredString(cx, cy - r - 9 * mm, self.a.grade(self.scores["Overall"]).upper())

        # facts
        c.setFillColor(colors.HexColor("#8ba39b"))
        c.setFont("Helvetica", 9)
        lines = [
            f"Date of audit      {self.date}",
            f"Pages crawled      {len(self.a.ok_pages)}",
            f"Checks run         {len(self.a.checks)}",
            f"Issues found       {len(self.issues)}",
        ]
        yy = h - 132 * mm
        for ln in lines:
            c.drawString(20 * mm, yy, ln)
            yy -= 6 * mm

        # what's inside
        inside = [
            "Executive summary with a weighted score across five categories",
            f"{len(self.issues)} findings, each with the evidence and the fix",
            f"Page-by-page table for {len(self.a.ok_pages)} crawled pages",
            "Method, scoring weights and the limits of this audit",
        ]
        c.setFillColor(MINT)
        c.setFont("Helvetica-Bold", 7)
        c.drawString(20 * mm, 118 * mm, "I N S I D E   T H I S   R E P O R T")
        c.setFillColor(colors.HexColor("#c9d8d2"))
        c.setFont("Helvetica", 8.5)
        yy = 111 * mm
        for item in inside:
            c.setFillColor(MINT)
            c.drawString(20 * mm, yy, "\u2014")
            c.setFillColor(colors.HexColor("#c9d8d2"))
            c.drawString(25 * mm, yy, item)
            yy -= 5.6 * mm

        # footer band
        c.setFillColor(colors.HexColor("#0f1b18"))
        c.rect(0, 0, w, 34 * mm, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(20 * mm, 22 * mm, self.brand.upper())
        c.setFillColor(colors.HexColor("#8ba39b"))
        c.setFont("Helvetica", 7.5)
        c.drawString(20 * mm, 17 * mm, "Hajipur, Bihar  \u00b7  kovik.online  \u00b7  +91 91992 64615")
        c.setFillColor(MINT)
        c.setFont("Helvetica-Bold", 7.5)
        c.drawRightString(w - 20 * mm, 22 * mm, f"POWERED BY {self.powered.upper()}")
        c.setFillColor(colors.HexColor("#8ba39b"))
        c.setFont("Helvetica", 7)
        c.drawRightString(w - 20 * mm, 17 * mm, "Our own crawl, scoring and reporting engine")

    # ---------------------------------------------------------------- build
    def build(self, path: str) -> str:
        doc = BaseDocTemplate(path, pagesize=A4,
                              leftMargin=18 * mm, rightMargin=18 * mm,
                              topMargin=24 * mm, bottomMargin=20 * mm,
                              title=f"SEO Audit \u2014 {self.site}", author=self.brand,
                              subject="Technical and on-page SEO audit",
                              creator=f"{self.powered} \u00b7 {self.site_name}")
        frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="main")
        doc.addPageTemplates([PageTemplate(id="main", frames=[frame], onPage=self._decorate)])

        story: List = [Spacer(1, 1), PageBreak()]
        story += self._summary()
        story += self._issues_section()
        story += self._pages_section()
        story += self._method_section()
        doc.build(story)
        for f in self.tmp:
            try:
                os.remove(f)
            except OSError:
                pass
        return path

    # ------------------------------------------------------------- summary
    def _summary(self) -> List:
        s = self.styles
        story: List = []
        story.append(Paragraph("Executive summary", s["KH1"]))
        story.append(Paragraph(
            f"A technical and on-page audit of <b>{self.site}</b>, covering "
            f"{len(self.a.ok_pages)} crawled pages. Every finding below was measured, not assumed — "
            f"each check records what was found on the page and what to change.", s["KBody"]))
        story.append(Spacer(1, 6 * mm))

        overall = self.scores["Overall"]
        head = Table(
            [[Paragraph(f'<font size="30" color="#0b1210"><b>{overall:.0f}</b></font>'
                        f'<font size="11" color="#5c6a64"> / 100</font>', s["KCell"]),
              Paragraph(f'<b>{self.a.grade(overall)}</b><br/>'
                        f'<font size="8" color="#5c6a64">Overall visibility score</font>', s["KCell"]),
              Paragraph(f'<b>{len(self.issues)}</b> issues found<br/>'
                        f'<font size="8" color="#5c6a64">'
                        f'{sum(1 for c in self.issues if c.status == "fail")} blocking, '
                        f'{sum(1 for c in self.issues if c.status == "warn")} to improve</font>', s["KCell"])]],
            colWidths=[42 * mm, 62 * mm, doc_width_rest()])
        head.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
            ("BOX", (0, 0), (-1, -1), 0.5, LINE),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ("TOPPADDING", (0, 0), (-1, -1), 10),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ]))
        story.append(head)
        story.append(Spacer(1, 7 * mm))

        chart = self._chart_scores()
        story.append(Image(chart, width=165 * mm, height=64 * mm))
        story.append(Spacer(1, 4 * mm))

        # priorities
        story.append(Paragraph("Fix these first", s["KH2"]))
        fails = [c for c in self.issues if c.status == "fail"]
        warns = [c for c in self.issues if c.status == "warn"]
        top = (fails + warns)[:5]
        if not top:
            story.append(Paragraph("Nothing critical was found in this crawl. "
                                   "Keep the monthly cadence and watch Core Web Vitals.", s["KBody"]))
        else:
            rows = [[Paragraph("#", s["KCellB"]), Paragraph("Issue", s["KCellB"]),
                     Paragraph("Why it matters", s["KCellB"]), Paragraph("Severity", s["KCellB"])]]
            for i, c in enumerate(top, 1):
                rows.append([Paragraph(str(i), s["KCell"]),
                             Paragraph(f"<b>{c.title}</b><br/><font size='7' color='#5c6a64'>{c.detail}</font>", s["KCell"]),
                             Paragraph(c.fix, s["KCell"]),
                             Paragraph(f'<font color="{sev_hex(c.severity)}"><b>{c.severity.upper()}</b></font>', s["KCell"])])
            t = Table(rows, colWidths=[8 * mm, 74 * mm, 68 * mm, 22 * mm], repeatRows=1)
            t.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), LIGHT),
                ("GRID", (0, 0), (-1, -1), 0.4, LINE),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]))
            story.append(t)
        story.append(PageBreak())
        return story

    # -------------------------------------------------------------- issues
    def _issues_section(self) -> List:
        s = self.styles
        story: List = [Paragraph("Findings in detail", s["KH1"]),
                       Paragraph("Grouped by severity. Each row states what was measured, "
                                 "on how many pages, and what to do about it.", s["KBody"]),
                       Spacer(1, 5 * mm)]
        if not self.issues:
            story.append(Paragraph("No failing checks in this crawl.", s["KBody"]))
            story.append(PageBreak())
            return story

        sev_chart = self._chart_severity()
        row = Table([[Image(sev_chart, width=42 * mm, height=42 * mm),
                      Paragraph(self._severity_text(), s["KBody"])]],
                    colWidths=[48 * mm, doc_width_rest()])
        row.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                 ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
        story.append(row)
        story.append(Spacer(1, 5 * mm))

        for sev in ("critical", "high", "medium", "low"):
            group = [c for c in self.issues if c.severity == sev]
            if not group:
                continue
            story.append(Paragraph(f"{sev.upper()} — {len(group)} issue"
                                   f"{'s' if len(group) > 1 else ''}", s["KH2"]))
            for c in group:
                story.append(self._issue_block(c))
                story.append(Spacer(1, 2.5 * mm))
        story.append(PageBreak())
        return story

    def _severity_text(self) -> str:
        n_fail = sum(1 for c in self.issues if c.status == "fail")
        n_warn = sum(1 for c in self.issues if c.status == "warn")
        return (f"<b>{n_fail} checks failed</b> and <b>{n_warn} need improvement</b>. "
                f"Critical items cost you rankings or trust today; high items cost you clicks; "
                f"medium and low items are the difference between ranking and ranking well.")

    def _issue_block(self, c) -> Table:
        s = self.styles
        left = [
            Paragraph(f'<font color="{sev_hex(c.severity)}"><b>{c.severity.upper()}</b></font>'
                      f'  ·  {c.category}', s["KEyebrow"]),
            Spacer(1, 1.5 * mm),
            Paragraph(f"<b>{c.title}</b>", ParagraphStyle(
                "t", parent=s["KCell"], fontSize=9.5, leading=12.5, textColor=INK)),
            Spacer(1, 1.5 * mm),
            Paragraph(c.detail, s["KCell"]),
        ]
        if c.affected:
            shown = c.affected[:4]
            more = len(c.affected) - len(shown)
            left.append(Spacer(1, 1.5 * mm))
            left.append(Paragraph("Affected: " + "; ".join(self.disp(x) for x in shown) +
                                  (f" and {more} more" if more > 0 else ""), s["KSmall"]))
        right = [Paragraph('<font color="#0e5e52"><b>WHAT TO DO</b></font>', s["KEyebrow"]),
                 Spacer(1, 1.5 * mm),
                 Paragraph(c.fix, s["KCell"])]
        t = Table([[left, right]], colWidths=[112 * mm, doc_width_rest() - 6 * mm])
        t.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BACKGROUND", (0, 0), (0, 0), colors.white),
            ("BACKGROUND", (1, 0), (1, 0), colors.HexColor("#f2f8f6")),
            ("BOX", (0, 0), (-1, -1), 0.5, LINE),
            ("LINEBEFORE", (1, 0), (1, 0), 1.4, MINT),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ("RIGHTPADDING", (0, 0), (-1, -1), 8),
            ("TOPPADDING", (0, 0), (-1, -1), 7),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ]))
        return t

    # --------------------------------------------------------------- pages
    def _pages_section(self) -> List:
        s = self.styles
        story: List = [Paragraph("Page-by-page", s["KH1"]),
                       Paragraph("Measured per page. A page score below 70 has more than two "
                                 "structural problems.", s["KBody"]), Spacer(1, 4 * mm)]
        rows = [[Paragraph(h, s["KCellB"]) for h in
                 ["URL", "Status", "Score", "Title", "Desc", "H1", "Words", "Alt gaps", "ms", "KB"]]]
        for r in self.a.page_rows():
            rows.append([
                Paragraph(self.disp(r["url"]).replace("&", "&amp;")[:64], s["KCell"]),
                Paragraph(str(r["status"]), s["KCell"]),
                Paragraph(f"<b>{r['score']}</b>", s["KCell"]),
                Paragraph(str(r["title_len"]), s["KCell"]),
                Paragraph(str(r["desc_len"]), s["KCell"]),
                Paragraph(str(r["h1"]), s["KCell"]),
                Paragraph(str(r["words"]), s["KCell"]),
                Paragraph(str(r["no_alt"]), s["KCell"]),
                Paragraph(str(r["ms"]), s["KCell"]),
                Paragraph(str(r["kb"]), s["KCell"]),
            ])
        t = Table(rows, colWidths=[74 * mm, 13 * mm, 13 * mm, 12 * mm, 12 * mm, 9 * mm,
                                   13 * mm, 15 * mm, 12 * mm, 11 * mm], repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), LIGHT),
            ("GRID", (0, 0), (-1, -1), 0.35, LINE),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#fafbfa")]),
        ]))
        story.append(t)
        story.append(PageBreak())
        return story

    # -------------------------------------------------------------- method
    def _method_section(self) -> List:
        s = self.styles
        story: List = [Paragraph("Method and limits", s["KH1"]),
                       Paragraph(
                           f"The engine fetched {len(self.a.pages)} pages from {self.site} "
                           f"(same host only, robots.txt respected, {self.a.c.max_depth} levels deep), "
                           f"parsed the HTML, and ran {len(self.a.checks)} checks. Response times are "
                           f"a single measurement from one location at one moment — treat them as a "
                           f"signal, not a benchmark.", s["KBody"]),
                       Spacer(1, 3 * mm),
                       Paragraph("<b>What this audit does not cover:</b> backlinks and authority, "
                                 "search volume and keyword difficulty, competitor rankings, "
                                 "Core Web Vitals field data from real users, paid search, or "
                                 "Google Business Profile performance. Those need Search Console, "
                                 "Analytics and a rank-tracking source.", s["KBody"]),
                       Spacer(1, 3 * mm),
                       Paragraph("<b>Scores</b> are a weighted average: Technical 30%, On-page 25%, "
                                 "Content 20%, Structured data 15%, Performance 10%. A pass scores 1, "
                                 "an improvement 0.5, a failure 0.", s["KBody"]),
                       Spacer(1, 8 * mm)]
        box = Table([[Paragraph(
            f"<b>Prepared by {self.brand}</b><br/>"
            f"Hajipur, Bihar · kovik.online · +91 91992 64615<br/>"
            f"<font color='#5c6a64'>Powered by {self.powered} — our own crawl, scoring and reporting "
            f"engine, built in-house.</font>", s["KCell"])]],
            colWidths=[doc_width_rest()])
        box.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
            ("BOX", (0, 0), (-1, -1), 0.5, LINE),
            ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ("TOPPADDING", (0, 0), (-1, -1), 10),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ]))
        story.append(box)
        return story


def doc_width_rest():
    return A4[0] - 36 * mm - 42 * mm - 62 * mm


def sev_hex(sev: str) -> str:
    return {"critical": "#a3341f", "high": "#c0561f", "medium": "#b0821f",
            "low": "#4b6b62", "info": "#5c6a64"}.get(sev, "#5c6a64")
