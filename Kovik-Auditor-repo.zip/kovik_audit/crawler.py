# -*- coding: utf-8 -*-
"""Kovik SEO Audit Engine — crawler.

Crawls a site politely, same host only, and returns raw page records.
"""
from __future__ import annotations

import time
import urllib.robotparser as robotparser
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from urllib.parse import urljoin, urlparse, urldefrag

import requests
from bs4 import BeautifulSoup

UA = "KovikAuditBot/1.0 (+https://kovik.online; SEO audit engine)"
DEFAULT_HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-IN,en;q=0.9",
}


@dataclass
class Page:
    url: str
    status: int = 0
    elapsed_ms: int = 0
    bytes: int = 0
    content_type: str = ""
    title: str = ""
    meta_description: str = ""
    h1: List[str] = field(default_factory=list)
    h2: List[str] = field(default_factory=list)
    images: int = 0
    images_no_alt: int = 0
    internal_links: int = 0
    external_links: int = 0
    canonical: str = ""
    robots_meta: str = ""
    og_tags: Dict[str, str] = field(default_factory=dict)
    jsonld_blocks: List[str] = field(default_factory=list)
    jsonld_valid: int = 0
    jsonld_types: List[str] = field(default_factory=list)
    words: int = 0
    viewport: str = ""
    lang: str = ""
    https: bool = False
    redirect_chain: List[str] = field(default_factory=list)
    links: List[str] = field(default_factory=list)
    error: str = ""
    headers: Dict[str, str] = field(default_factory=dict)


def norm(url: str) -> str:
    url, _ = urldefrag(url)
    p = urlparse(url)
    path = p.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")
    q = ("?" + p.query) if p.query else ""
    return f"{p.scheme}://{p.netloc}{path}{q}"


def same_host(a: str, b: str) -> bool:
    ha, hb = urlparse(a).netloc.lower(), urlparse(b).netloc.lower()
    return ha.replace("www.", "") == hb.replace("www.", "")


class Crawler:
    def __init__(self, start_url: str, max_pages: int = 10, max_depth: int = 2,
                 delay: float = 0.4, timeout: int = 20, verbose: bool = True):
        self.start = norm(start_url)
        self.max_pages = max_pages
        self.max_depth = max_depth
        self.delay = delay
        self.timeout = timeout
        self.verbose = verbose
        self.session = requests.Session()
        self.session.headers.update(DEFAULT_HEADERS)
        self.robots: Optional[robotparser.RobotFileParser] = None
        self.robots_url = ""
        self.sitemap_urls: List[str] = []
        self.pages: List[Page] = []
        self.seen: set = set()
        self.broken: List[dict] = []

    # ---------------------------------------------------------------- robots
    def load_robots(self) -> None:
        parsed = urlparse(self.start)
        self.robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        rp = robotparser.RobotFileParser()
        try:
            r = self.session.get(self.robots_url, timeout=self.timeout)
            if r.status_code == 200:
                rp.parse(r.text.splitlines())
                for line in r.text.splitlines():
                    if line.lower().startswith("sitemap:"):
                        self.sitemap_urls.append(line.split(":", 1)[1].strip())
            else:
                rp.parse([])
        except requests.RequestException:
            rp.parse([])
        self.robots = rp

    def allowed(self, url: str) -> bool:
        if not self.robots:
            return True
        try:
            return self.robots.can_fetch(UA, url)
        except Exception:
            return True

    # ---------------------------------------------------------------- fetch
    def fetch(self, url: str) -> Page:
        page = Page(url=url)
        page.https = url.startswith("https://")
        try:
            t0 = time.time()
            resp = self.session.get(url, timeout=self.timeout, allow_redirects=True)
            page.elapsed_ms = int((time.time() - t0) * 1000)
            page.status = resp.status_code
            page.bytes = len(resp.content)
            page.content_type = resp.headers.get("Content-Type", "")
            page.headers = {k.lower(): v for k, v in resp.headers.items()}
            page.redirect_chain = [h.url for h in resp.history] if resp.history else []
            if resp.status_code >= 400:
                page.error = f"HTTP {resp.status_code}"
                return page
            if "html" not in page.content_type.lower():
                page.error = "not HTML"
                return page
            self.parse(page, resp.text)
        except requests.RequestException as exc:
            page.error = str(exc)[:160]
        return page

    # ---------------------------------------------------------------- parse
    def parse(self, page: Page, html: str) -> None:
        soup = BeautifulSoup(html, "lxml")

        t = soup.find("title")
        page.title = t.get_text(strip=True) if t else ""

        md = soup.find("meta", attrs={"name": "description"})
        page.meta_description = (md.get("content") or "").strip() if md else ""

        page.h1 = [h.get_text(" ", strip=True) for h in soup.find_all("h1")]
        page.h2 = [h.get_text(" ", strip=True) for h in soup.find_all("h2")]

        imgs = soup.find_all("img")
        page.images = len(imgs)
        page.images_no_alt = sum(1 for i in imgs if not (i.get("alt") or "").strip())

        base_host = page.url
        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if href.startswith(("mailto:", "tel:", "javascript:", "#")):
                continue
            target = urljoin(page.url, href)
            if urlparse(target).scheme not in ("http", "https"):
                continue
            if same_host(target, base_host):
                page.internal_links += 1
                page.links.append(norm(target))
            else:
                page.external_links += 1

        can = soup.find("link", rel=lambda v: v and "canonical" in v)
        page.canonical = (can.get("href") or "").strip() if can else ""

        rb = soup.find("meta", attrs={"name": "robots"})
        page.robots_meta = (rb.get("content") or "").strip() if rb else ""

        for prop in ("og:title", "og:description", "og:image", "og:type", "og:url"):
            tag = soup.find("meta", attrs={"property": prop})
            if tag and tag.get("content"):
                page.og_tags[prop] = tag["content"]

        for s in soup.find_all("script", attrs={"type": "application/ld+json"}):
            raw = s.string or s.get_text() or ""
            if raw.strip():
                page.jsonld_blocks.append(raw)
                try:
                    import json
                    data = json.loads(raw)
                    page.jsonld_valid += 1
                    items = data if isinstance(data, list) else [data]
                    for it in items:
                        if isinstance(it, dict) and it.get("@type"):
                            tp = it["@type"]
                            page.jsonld_types.extend(tp if isinstance(tp, list) else [tp])
                except Exception:
                    pass

        vp = soup.find("meta", attrs={"name": "viewport"})
        page.viewport = (vp.get("content") or "") if vp else ""

        html_tag = soup.find("html")
        page.lang = (html_tag.get("lang") or "") if html_tag else ""

        for junk in soup(["script", "style", "noscript", "template"]):
            junk.decompose()
        text = soup.get_text(" ", strip=True)
        page.words = len(text.split())

    # ---------------------------------------------------------------- crawl
    def run(self) -> List[Page]:
        self.load_robots()
        queue = deque([(self.start, 0)])
        self.seen.add(self.start)
        while queue and len(self.pages) < self.max_pages:
            url, depth = queue.popleft()
            if not self.allowed(url):
                if self.verbose:
                    print(f"  blocked by robots.txt: {url}")
                continue
            if self.verbose:
                print(f"  [{len(self.pages)+1}/{self.max_pages}] {url}")
            page = self.fetch(url)
            self.pages.append(page)
            if page.status >= 400 or page.error:
                self.broken.append({"url": url, "status": page.status, "error": page.error})
                continue
            if depth >= self.max_depth:
                continue
            for target in page.links:
                if target in self.seen:
                    continue
                self.seen.add(target)
                queue.append((target, depth + 1))
            time.sleep(self.delay)
        return self.pages
