"""End-to-end test: serve the built Kovik site on localhost and audit it."""
import functools, http.server, socketserver, threading, sys, os

ROOT = "/scratch/work/build/site"
PORT = 8791

Handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
socketserver.TCPServer.allow_reuse_address = True
httpd = socketserver.TCPServer(("127.0.0.1", PORT), Handler)
t = threading.Thread(target=httpd.serve_forever, daemon=True)
t.start()

os.environ["NO_PROXY"] = "127.0.0.1,localhost"
os.environ["no_proxy"] = "127.0.0.1,localhost"
os.environ["NO_COLOR"] = "1"

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import audit

try:
    rc = audit.main([f"http://127.0.0.1:{PORT}/", "--pages", "10", "--depth", "2",
                     "--out", "/scratch/work/kovik-audit/sample-report.pdf",
                     "--json", "/scratch/work/kovik-audit/sample.json",
                     "--csv", "/scratch/work/kovik-audit/sample.csv",
                     "--delay", "0.05", "--quiet", "--label", "https://kovik.online"])
finally:
    httpd.shutdown()
print("exit", rc)
